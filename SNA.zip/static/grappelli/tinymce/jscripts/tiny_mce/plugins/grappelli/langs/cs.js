tinyMCE.addI18n("cs.grappelli",{
grappelli_adv_desc:"Zobrazit/Skrýt pokročilé možnosti",
grappelli_documentstructure_desc:"Zobrazit/Skrýt strukturu dokumentu",
});
